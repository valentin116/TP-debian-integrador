 poweroff
 poweroff
-c 4 8.8.8.8
ping -c 4 8.8.8.8
reboot
cat > /etc/apt/source.list
apt update
cat /etc/apt/source.list
clear
cat /etc/apt/sources.list
cat > /etc/apt/sources.list
clear
cat /etc/apt/sources.list
clear
apt update
clear
apt list --upgradable
cat /etc/os-release
apt upgrade -y
clear
cat /etc/debian_version
sed -i 's/bullseye/bookworm/g'
sed -i 's/bullseye/bookworm/g' /etc/apt/sources.list
cat /etc/apt/sources.list
clear
cat /etc/apt/sources.list
clear
apt update
clear
apt full-upgrade -y
clear
cat /etc/debian_version
reboot
cat /etc/debian_version
clear
apt install -y openssh-server
clear
mkdir -p /root/.ssh
ssh-keygen -t rsa -b 4096
 cat /root/.ssh/id_rsa.pub > /root/.ssh/authorized_keys
chmood 700 /root/.ssh 
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
grep permitrootlogin 
ls -l /root/.ssh
mkdir -p /etc/ssh/sshd_config.d
clear
cat > /etc/ssh/sshd_config.d/root-login.conf
sshd -t
systemctl restart ssh
systemctl status ssh --no-pager
clear
apt install -y apache2 php libapache2-mod-php
clear
systemtl status apache2 --no-pager
clear
systemctl status apache2 --no-pager
clear
ls -l /root
ls -la /root
find / -name "index.php" -o -name "logo.png" -o -name "db.sql" 2>"/dev/null
find / -name index.php
find / -name logo.png
find / -name db.sql
clear
cat > /root/index.php
ls /usr/share/apache2/icons/debian-logo.png
cp $(find /usr/share -iname "*.png* -print
ls -l /root/index.php /root/logo.png
find /usr/share -iname "*.png" -print -quit
find /usr/share/icons/hicolor/32x32/apps/display-im6.q16.png /root/logo.png
clear
cp /usr/share/icons/hicolor/32x32/apps/display-im6.q16.png /root/logo.png
ls -l /root/index,php /root/logo.png
clear
echo "TPServer funcionando - Apache con PHP" > /root/index.php
ls -l /root/logo.png
ls -l /root/indec.php /root/logo.png
clear
echo "TPServer funcionando - Apache con PHP" tee /root/index.php
ls -l /root/index.php /root/logo.png
clear
cp /root/logo.png /var/www/html/logo.png
clear
cp /root/index.php /var/www/html/index.php
cp /root/logo.png /var/www/html/logo.png
ls -l /var/www/html/index.php /var/www/html/logo.png
clear
curl http://localhost/index.php
clear
apt install -y mariadb-server
clear
systemctl status mariadb --no-pager
clear
cat > /root/db.sql
ls -l /root/db.sql
clear
mariadb < /root/db.sql
maria -e "USE tp; SHOW TABLES; SELECT * FROM prueba;"
clear
mariadb -e "USE tp; SHOW TABLES; SELECT * FROM prueba;"
poweroff
